# -*- coding: utf-8 -*-
"""
Created on Tue Jan  5 16:22:29 2021

@author: mirash
"""
from sklearn.feature_selection import SelectKBest

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier # for RandomForest Algorithm
import pymysql
conn=pymysql.connect(host='localhost',port=int(3306),user='root',passwd='Amal#1709',db='Mushroom_DB')
Mush_df=pd.read_sql_query("SELECT * FROM mushrooms",conn)
Mush_df=Mush_df.replace('?',np.nan)
Mush_df=Mush_df.dropna(axis=1) #more than 25 perc(2480/8124) of data is missing ,so droping column
Mush_df=Mush_df.drop('veil-type',axis=1)
y = pd.DataFrame(Mush_df['class'])
x=Mush_df.drop('class',axis=1)

x=pd.get_dummies(x)

model_columns = list(x.columns)
select_features_edible_df=pd.read_sql_query("select  `bruises`,`cap-surface`,`gill-color`,`gill-size`,`gill-spacing`,`habitat`,`odor`,`population`,`ring-number`,`ring-type`,`spore-print-color`,`stalk-color-above-ring`,`stalk-shape`,`stalk-surface-above-ring` ,`stalk-surface-below-ring`  from mushrooms where class='e' LIMIT 0,10;",conn)

select_features_poison_df=pd.read_sql_query("select  `bruises`,`cap-surface`,`gill-color`,`gill-size`,`gill-spacing`,`habitat`,`odor`,`population`,`ring-number`,`ring-type`,`spore-print-color`,`stalk-color-above-ring`,`stalk-shape`,`stalk-surface-above-ring` ,`stalk-surface-below-ring` from mushrooms where class='p' LIMIT 0,10;",conn)

edible=pd.DataFrame(select_features_edible_df.head(10))
poison=pd.DataFrame(select_features_poison_df.head(10))
n = np.reshape(edible.iloc[4:5], (1,15))


#n.to_csv("dummy.csv")
query=pd.get_dummies(n)
#query.to_csv("query.csv")
print(query.columns)


#print(model_columns)
for col in model_columns:
    if col not in query.columns:
       query[col] = 0  
       
       
       
rf = RandomForestClassifier()
rf.fit(x,y)
print(rf.predict(query))
        