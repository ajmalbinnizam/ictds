# -*- coding: utf-8 -*-
"""
Created on Sun Jan 10 16:29:51 2021

@author: mirash
"""


import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import pymysql
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
import seaborn as sns
import matplotlib.pyplot as plt
conn=pymysql.connect(host='localhost',port=int(3306),user='root',passwd='Amal#1709',db='Mushroom_DB')
Mush_df=pd.read_sql_query("SELECT * FROM mushrooms",conn)
Mush_df=Mush_df.replace('?',np.nan)
Mush_df=Mush_df.dropna(axis=1) #more than 25 perc(2480/8124) of data is missing ,so droping column
Mush_df=Mush_df.drop('veil-type',axis=1)
y = pd.DataFrame(Mush_df['class'])
x=Mush_df.drop('class',axis=1)


LE = LabelEncoder()
col = x.columns
for i in col:
    x[i] = LE.fit_transform(x[i])
    
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.4,random_state=42)
from sklearn.ensemble import RandomForestClassifier

rf = RandomForestClassifier()
rf.fit(x_train, y_train)
print(pd.Series(rf.feature_importances_,index=x.columns).sort_values(ascending=False)*100)

# odor                        14.747991
# gill-size                   13.844014
# gill-color                  11.526215
# spore-print-color           11.501707
# ring-type                    7.969051
# gill-spacing                 6.165949
# population                   6.078123
# stalk-surface-above-ring     5.884208
# bruises                      5.152729
# stalk-surface-below-ring     3.795556
# habitat                      3.022032
# stalk-color-above-ring       2.380896
# stalk-shape                  1.690168
# stalk-color-below-ring       1.648904
# cap-color                    1.397286
# ring-number                  1.115891
# cap-surface                  1.087782
# cap-shape                    0.553089
# gill-attachment              0.262245
# veil-color                   0.176164



