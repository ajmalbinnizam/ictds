# -*- coding: utf-8 -*-
"""
Created on Thu Jan  7 09:48:11 2021

@author: mirash
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier # for RandomForest Algorithm
import pymysql
import pickle
from model_new import LE

modelfile=open('model_columns.pickle','rb')
model_columns =pickle.load(modelfile)
#print(model_columns)
modelfile.close() 

#edible
#['t',	's',	'k',	'b',	'c',	'g',	'a',	'n',	'o',	'p',	'n',	'w',	'e',	's',	's']
#['t',	's',	'n',	'b',	'c',	'm',	'l',	'n',	'o',	'p',	'n',	'w',	'e',	's',	's']
#['f',	's',	'k',	'b',	'w',	'g',	'n',	'a',	'o',	'e',	'n',	'w',	't',	's',	's']
#poison
#['t',	's',	'k',	'n',	'c',	'u',	'p',	's',	'o',	'p',	'k',	'w',	'e',	's',	's']
#['t',	'y',	'n',	'n',	'c',	'u',	'p',	's',	'o',	'p',	'k',	'w',	'e',	's',	's']


# bruises=request.form['bruises']
# cap_surface = request.form['cap_surface']
# gill_color = request.form['gill_color']
# gill_size= request.form['gill_size']
# gill_spacing= request.form['gill_spacing']
# habitat = request.form['habitat']
# odor = request.form['odor']
# population= request.form['population']
# ring_number = request.form['ring_number']
# ring_type= request.form['ring_number']
# spore_print_color = request.form['spore_print_color']
# stalk_color_above_ring= request.form['stalk_color_above_ring']
# stalk_shape=request.form['stalk_shape']
# stalk_surface_above_ring = request.form['stalk_surface_above_ring']
# stalk_surface_below_ring=request.form['stalk_surface_below_ring']     


   
    # mushroomPredictInput = [bruises
    #         ,cap_surface
    #         ,gill_color
    #         ,gill_size
    #         ,gill_spacing
    #         ,habitat
    #         ,odor
    #         ,population
    #         ,ring_number
    #         ,ring_type
    #         ,cap_shape
    #         ,bruises
    #         ,spore_print_color
    #        , stalk_color_above_ring
    #         ,stalk_shape
    #        , stalk_surface_above_ring
    #         ,stalk_surface_below_ring]
    
mushroomPredictInput=['t',	's',	'k',	'n',	'c',	'u',	'p',	's',	'o',	'p',	'k',	'w',	'e',	's',	's']#features = np.reshape(features, (1,-1))

mushroomPredictInput = np.reshape(mushroomPredictInput, (1,15))
mushroomPredictInputfinal = pd.DataFrame(mushroomPredictInput,columns=['bruises'
                               ,'cap-surface'
                               ,'gill-color'
                               ,'gill-size'
                               ,'gill-spacing'
                               ,'habitat'
                               ,'odor'
                               ,'population'
                               ,'ring-number'
                               ,'ring-type'
                               ,'spore-print-color'
                               ,'stalk-color-above-ring'
                               ,'stalk-shape'
                               ,'stalk-surface-above-ring' 
                               ,'stalk-surface-below-ring' ])

query=pd.get_dummies(mushroomPredictInputfinal)

query.to_csv("queryafter.csv")

    #model_columns = list(x.columns)
for col in model_columns:
    if col not in query.columns:
       query[col] = 0   

#query.to_csv("input.csv")
print(query)
              
inputModelFile=open('randomForrModel.pkl','rb')
model =pickle.load(inputModelFile)
inputModelFile.close()
data = pd.read_csv('input.csv')
prediction = model.predict(query)
query=[[]]
mushroomPredictInput=[[]]
arr_out = prediction.item()
print(prediction)
prediction=''

model = pickle.load(open('model.pkl', 'rb'))
mushroomPredictInput=['t',	'y',	'n',	'n',	'c',	'u',	'p',	's',	'o',	'p',	'k',	'w',	'e',	's',	's']
#mushroomPredictInput = np.reshape(mushroomPredictInput.transpose(), (1,-1))
test =mushroomPredictInput

test = LE.fit_transform(test)
test = np.reshape(test, (1,-1))
out_test = model.predict(test)
arr_out = out_test.item()
print(arr_out)
if arr_out == 'e':
   text = "Bravo, It's Edible"
   #return render_template("result.html", res = text)
elif arr_out == 'p':
     text = "Oops... Don't eat it, It's Poisonous"
     
     
 
            



   
    
   

