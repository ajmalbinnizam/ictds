# -*- coding: utf-8 -*-
"""
Created on Sun Jan 10 16:02:54 2021

@author: mirash
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import pymysql
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
import seaborn as sns
import matplotlib.pyplot as plt
conn=pymysql.connect(host='localhost',port=int(3306),user='root',passwd='Amal#1709',db='Mushroom_DB')
Mush_df=pd.read_sql_query("SELECT * FROM mushrooms",conn)
Mush_df=Mush_df.replace('?',np.nan)
Mush_df=Mush_df.dropna(axis=1) #more than 25 perc(2480/8124) of data is missing ,so droping column
Mush_df=Mush_df.drop('veil-type',axis=1)
y = pd.DataFrame(Mush_df['class'])
x=Mush_df.drop('class',axis=1)


LE = LabelEncoder()
col = x.columns
for i in col:
    x[i] = LE.fit_transform(x[i])
    
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.4,random_state=42)
    
def select_features(x_train,y_train,x_test,method):
    fs=SelectKBest(score_func=method,k=16)
    fs.fit(x_train,y_train)
    x_train_fs=fs.transform(x_train)
    x_test_fs=fs.transform(x_test)
    return x_train_fs,x_test_fs,fs

x_train_fs,x_test_fs,fs=select_features(x_train,y_train,x_test,chi2)
feature_scores=[tup for tup in zip(fs.scores_,x.columns)]
print('top 30 chi-squared features:\n')
for i,j in sorted(feature_scores,key=lambda tup:tup[0],reverse=True)[:16]:
     print('%s: %f' %(j,i))
# plt.bar([i for i in range(len(fs.scores_))],fs.scores_)
# plt.title('chi square feature importance')
# plt.show()


# =============================================================================
# gill-color: 3662.744847
# ring-type: 1181.748816
# gill-size: 1002.944306
# bruises: 726.102639
# gill-spacing: 479.007645
# habitat: 439.808436
# spore-print-color: 242.808943
# population: 182.392048
# stalk-surface-above-ring: 130.583916
# cap-surface: 129.588050
# stalk-surface-below-ring: 125.958910
# stalk-color-below-ring: 62.891959
# stalk-color-above-ring: 60.904004
# odor: 53.078654
# stalk-shape: 21.817667
# ring-number: 15.515834
# =============================================================================

