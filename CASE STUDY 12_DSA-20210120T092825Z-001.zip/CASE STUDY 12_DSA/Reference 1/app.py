from flask import Flask, render_template, request
import pickle
import numpy as np
from ChiModel import LE

app = Flask(__name__)
model = pickle.load(open('chi.pkl', 'rb'))
@app.route('/')
def main():
    return render_template("index.html")

@app.route('/classification')
def classification():
    return render_template("test.html")
    

@app.route('/classification_btn1',methods=['POST','GET'])
def classification_btn():
    print("top")
    gill_color = request.form['gill-color']           
    ring_type=request.form['ring-type']
    gill_size=request.form['gill-size']
    bruises=request.form['bruises']
    gill_spacing=request.form['gill-spacing']
    habitat=request.form['habitat']
    spore_print_color=request.form['spore-print-color']
    population=request.form['population']
    stalk_surface_above_ring=request.form['stalk-surface-above-ring']
    cap_surface=request.form['cap-surface']
    stalk_surface_below_ring=request.form['stalk-surface-below-ring']
    stalk_color_below_ring=request.form['stalk-color-below-ring']
    stalk_color_above_ring=request.form['stalk-color-above-ring']
    odor=request.form['odor']
    stalk_shape=request.form['stalk-shape']
    ring_number=request.form['ring-number']

    mushroomPredictInput = [gill_color,
                            ring_type,
                            gill_size,
                            bruises,
                            gill_spacing,
                            habitat,
                            spore_print_color,
                            population,
                            stalk_surface_above_ring,
                            cap_surface,
                            stalk_surface_below_ring,
                            stalk_color_below_ring,
                            stalk_color_above_ring,
                            odor,
                            stalk_shape,
                            ring_number]
    
    test=mushroomPredictInput
    test = LE.fit_transform(test)
    test = np.reshape(test, (1,-1))
    out_test = model.predict(test)
    print(out_test)
    arr_out = out_test.item() 
   
    
    return render_template("result.html",results=arr_out[0])
    

@app.route('/visual')
def visual():
    return render_template("statistics.html")

@app.route('/types')
def types():
    return render_template("types.html")


if  __name__ == '__main__':
    app.run(port=9999)