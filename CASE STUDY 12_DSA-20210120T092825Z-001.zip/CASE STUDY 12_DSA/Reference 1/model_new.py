# =============================================================================
# Create Model for prediction.Pickle file generation.
# =============================================================================
from sklearn.preprocessing import LabelEncoder
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

import pickle
import pymysql
#Db connection string
conn=pymysql.connect(host='localhost',port=int(3306),user='root',passwd='Amal#1709',db='mushroom_db')

#fetch data with selected features for model building
data=pd.read_sql_query("select class, `gill-color`,`ring-type`, `gill-size`,`bruises`,`gill-spacing`,`habitat`, `spore-print-color`,`population`, `stalk-surface-above-ring`, `cap-surface`, `stalk-surface-below-ring`, `stalk-color-below-ring`, `stalk-color-above-ring`, `odor`,`stalk-shape`,`ring-number` from mushrooms",conn)

#Dependent and independent feature seperation
x = data.drop('class', axis = 1)
y = data['class']

#Applying Label Encoding
LE = LabelEncoder()
col = x.columns
for i in col:
    x[i] = LE.fit_transform(x[i])

x_train, x_test, y_train, y_test = train_test_split(x, y, random_state = 42, test_size = 0.3)
#KNN model traing
classifier = KNeighborsClassifier(n_neighbors=3, metric='minkowski')
classifier.fit(x, y)
    
y_pred = classifier.predict(x_test)
#pickle file creation for model
pickle.dump(classifier,open('model.pkl', 'wb'))
conn.commit()
conn.close()




def saveMushroomData(mushroomdata):
    
    mydb=pymysql.connect(host='localhost',port=int(3306),user='root',passwd='Amal#1709',db='mushroom_db', autocommit=True)
    mycursor = mydb.cursor()
    sql="insert into mushrooms_data (class, `gill-color`,`ring-type`, `gill-size`,`bruises`,`gill-spacing`,`habitat`, `spore-print-color`,`population`, `stalk-surface-above-ring`, `cap-surface`, `stalk-surface-below-ring`, `stalk-color-below-ring`, `stalk-color-above-ring`, `odor`,`stalk-shape`,`ring-number`) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    val=mushroomdata
    mycursor.execute(sql, val)
    mydb.commit()
    return True


#features selected for model training
# =============================================================================
# `gill-color`
# `ring-type`
# `gill-size`
# `bruises`
# `gill-spacing`
# `habitat`
# `spore-print-color`
# `population`
# `stalk-surface-above-ring`
# `cap-surface`
# `stalk-surface-below-ring`
# `stalk-color-below-ring`
# `stalk-color-above-ring`
# `odor`
# `stalk-shape`
# `ring-number`
# =============================================================================
