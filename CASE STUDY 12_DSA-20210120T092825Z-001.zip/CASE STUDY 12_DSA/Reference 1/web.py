from flask import Flask, render_template, request
import pickle
import numpy as np
from model_new import LE
import model_new as mdl
app = Flask(__name__)
model = pickle.load(open('model.pkl', 'rb'))
@app.route('/')
def main():
    return render_template("index.html")

@app.route('/classification')
def classification():
    return render_template("classification.html")


@app.route('/classification_btn',methods=['POST','GET'])
def classification_btn():
    
    gill_color = request.form['gill_color']  
             
    ring_type=request.form['ring_type']
     
    gill_size=request.form['gill_size']
    bruises=request.form['bruises']
    gill_spacing=request.form['gill_spacing']
    habitat=request.form['habitat']
    spore_print_color=request.form['spore_print_color']
    population=request.form['population']
    stalk_surface_above_ring=request.form['stalk_surface_above_ring']
    cap_surface=request.form['cap_surface']
    stalk_surface_below_ring=request.form['stalk_surface_below_ring']
    stalk_color_below_ring=request.form['stalk_color_below_ring']
    stalk_color_above_ring=request.form['stalk_color_above_ring']
    odor=request.form['odor']
    stalk_shape=request.form['stalk_shape']
    ring_number=request.form['ring_number']
    
    mushroomPredictInput = [gill_color,
                            ring_type,
                            gill_size,
                            bruises,
                            gill_spacing,
                            habitat,
                            spore_print_color,
                            population,
                            stalk_surface_above_ring,
                            cap_surface,
                            stalk_surface_below_ring,
                            stalk_color_below_ring,
                            stalk_color_above_ring,
                            odor,
                            stalk_shape,
                            ring_number]
    
    test=mushroomPredictInput
    print(test)
    test = LE.fit_transform(test)
    test = np.reshape(test, (1,-1))
    out_test = model.predict(test)
    print(out_test[0])
    arr_out = out_test.item() 
   
    
    return render_template("result.html",results=arr_out[0])
    

@app.route('/visual')
def visual():
    return render_template("statistics.html")

@app.route('/types')
def types():
    return render_template("types.html")
@app.route('/datacollection')
def datacollection():
    return render_template("datacollection.html")


@app.route('/save_btn',methods=['POST','GET'])
def save_btn():
     if request.method == 'GET':
        return render_template('datacollection.html')
     else:
         
            
            class_type =  request.form['class_type'] 
           
            gill_color = request.form['gill_color'] 
                  
            ring_type=request.form['ring_type']
            
            gill_size=request.form['gill_size']
           
            bruises=request.form['bruises']
            gill_spacing=request.form['gill_spacing']
            habitat=request.form['habitat']
            spore_print_color=request.form['spore_print_color']
            population=request.form['population']
            stalk_surface_above_ring=request.form['stalk_surface_above_ring']
            cap_surface=request.form['cap_surface']
            stalk_surface_below_ring=request.form['stalk_surface_below_ring']
            stalk_color_below_ring=request.form['stalk_color_below_ring']
            stalk_color_above_ring=request.form['stalk_color_above_ring']
            odor=request.form['odor']
            stalk_shape=request.form['stalk_shape']
            ring_number=request.form['ring_number']
            
            mushroomPredictInput =  [class_type 
                                    ,gill_color,
                                    ring_type,
                                    gill_size,
                                    bruises,
                                    gill_spacing,
                                    habitat,
                                    spore_print_color,
                                    population,
                                    stalk_surface_above_ring,
                                    cap_surface,
                                    stalk_surface_below_ring,
                                    stalk_color_below_ring,
                                    stalk_color_above_ring,
                                    odor,
                                    stalk_shape,
                                    ring_number]
            
            
            save=mdl.saveMushroomData(mushroomPredictInput)
            return  render_template('dbresult.html', results="Data saved Successfully")

if  __name__ == '__main__':
    app.run(port=9999)