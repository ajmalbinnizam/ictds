import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn import preprocessing
import pickle

label=preprocessing.LabelEncoder()

data=pd.read_csv('mushrooms.csv')

col=data.columns
for i in col:
    data[i]=label.fit_transform(data[i])
    
y=data['class']
X=data.drop(['class','veil-type','veil-color','cap-shape','gill-attachment','cap-surface','stalk-color-below-ring','ring-number','cap-color','stalk-color-above-ring'],axis=1)


X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.25,random_state=42)

rf=RandomForestClassifier()
rf.fit(X_train,y_train)
y_pred=rf.predict(X_test)

pickle.dump(rf,open('model.pkl','wb'))
