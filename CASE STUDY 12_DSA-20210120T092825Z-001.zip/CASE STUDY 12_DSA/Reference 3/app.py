from flask import Flask,render_template,request,g
import pickle
import sqlite3

app=Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
def connect_db():
    sql=sqlite3.connect('mushroom.db')
    sql.row_factory=sqlite3.Row
    return sql
def get_db():
    if not hasattr(g, 'sqlite_db'):
        g.sqlite_db = connect_db()
    return g.sqlite_db
@app.teardown_appcontext
def close_db(error):
    if hasattr(g, 'sqlite_db'):
        g.sqlite_db.close()
      
    
model=pickle.load(open('model.pkl','rb'))
@app.route('/')
def test():
    return render_template('index.html')
@app.route('/result',methods=['post'])
def predict():
    val1=float(request.values['bruises'])
    val2=float(request.values['odour'])
    val3=float(request.values['gill-spacing'])
    val4=float(request.values['gill-size'])
    val5=float(request.values['gill-colour'])
    val6=float(request.values['stalk-shape'])
    val7=float(request.values['Stalk-root'])
    val8=float(request.values['stalk-surface-above'])
    val9=float(request.values['stalk-surface-below-ring'])
    val10=float(request.values['ring-type'])
    val11=float(request.values['spore-print-colour'])
    val12=float(request.values['population'])
    val13=float(request.values['habitat'])
    
 
    inp=[[val1,val2,val3,val4,val5,val6,val7,val8,val9,val10,val11,val12,val13]]
    
    db = get_db()
    db.execute('insert into mushroom (bruises, odour, gill_spacing, gill_size, gill_colour, stalk_shape, stalk_root, stalk_surface_above, stalk_surface_below_ring, ring_type, spore_print_colour, population, habitat) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',[val1,val2,val3,val4,val5,val6,val7,val8,val9,val10,val11,val12,val13])
    db.commit()
        
    output=model.predict(inp)
    
    output=output.item()
    
   
    
    
    if (output==0): 
        res='EDIBLE'
    else:
        res='POISONOUS'
    return render_template('index.html',prediction_text="The mushroom is {}".format(res))

@app.route('/viewresults')
def viewresults():
    db = get_db()
    cur = db.execute('select rowid,* from mushroom')
    results = cur.fetchall()
    return '<h1>bruises {}. odour {}. gill-spacing {}. gill-size {}. gill-colour {}. stalk-shape {}. stalk-root {}. stalk-surface-above {}. stalk-surface-below {}. ring-type {}. spore-print-colour {}. population {}. habitat {}. </h1>'.format(results[1]['bruises'],
                                                                results[1]['odour'],
                                                                results[1]['gill_spacing'],
                                                                 results[1]['gill_size'],
                                                                 results[1]['gill_colour'],
                                                                 results[1]['stalk_shape'],
                                                                 results[1]['stalk_root'],
                                                                 results[1]['stalk_surface_above'],
                                                                 results[1]['stalk_surface_below_ring'],
                                                                 results[1]['ring_type'],
                                                                results[1]['spore_print_color'],
                                                                results[1]['population'],
                                                                 results[1]['habitat'])



if __name__=="__main__":
    app.run()
    