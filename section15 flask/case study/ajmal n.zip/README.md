# Iris-prediction-using-flask


https://github.com/ajmalbinnizam/irisprediction