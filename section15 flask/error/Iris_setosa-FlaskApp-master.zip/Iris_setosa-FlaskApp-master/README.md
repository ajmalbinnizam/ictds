# IRIS SETOSA : Flask App
Machine learning model to differentiate between Iris setosa, Iris Virginica, Iris versicolor, deployed on a web app using a Flask.


<img src="IMAGES/Index.png" ><img src="IMAGES/Result.png"  > 
