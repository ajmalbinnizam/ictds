# MovingCar
Moving Car animation using CSS

![alt text](https://github.com/LostStruct24/MovingCar/blob/main/images/Moving-Car.gif)
