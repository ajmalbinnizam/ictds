import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
data=pd.read_csv("mushroom.csv")

from sklearn.preprocessing import LabelEncoder
labelenc=LabelEncoder()
for column in data.columns:
    data[column] = labelenc.fit_transform(data[column])
x=pd.DataFrame(data,columns=['cap-shape','veil-color','population', 'habitat'])
y=data['class']
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.3,random_state=32)
from sklearn.ensemble import RandomForestClassifier
rf_model=RandomForestClassifier()
rf_model.fit(x_train,y_train)
pickle.dump(rf_model,open("model.pkl","wb"))