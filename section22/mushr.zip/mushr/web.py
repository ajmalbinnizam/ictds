from flask import Flask, render_template, request, redirect
from flask_mysqldb import MySQL
import pickle
app =Flask(__name__, template_folder='template', static_folder='static')
app.config['TESTING'] = True
model =pickle.load(open('model.pkl', 'rb'))
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'mysql '
mysql = MySQL(app)
@app.route('/')
def home():
    return render_template('home.html')
@app.route('/about')
def about():
    return render_template('about.html')
@app.route('/type')
def type():
    return render_template('type.html')
@app.route('/predict',methods=['POST','GET'])
def predict():
    # One - hot Encoding
    #data_enc = pd.get_dummies(data)
    #data_enc.head()
    if (request.method == 'POST'):
        chp = request.form['cap-shape']
        od = request.form['odor']
        gil = request.form['gill-size']
        pop = request.form['population']
        hab = request.form['habitat']
        cur = mysql.connection.cursor()
        cur.execute("CREATE TABLE mushroom(id int NOT NULL AUTO_INCREMENT,cap-shapes float,odor float,gill-size float,population float,habitat float,PRIMARY KEY(id)")
        cur.execute('insert into  mushroom (cap-shape,odor,gill-size,population,habitat) values (?,?, ?, ?, ?, ?)',[chp, od, gil, pop, hab])
        mysql.connection.commit()
    #return '<h1> id {}.\
    #                cap_shape{}.\
     #                odor{}.\
      #              gill-size{}.\
       #              population {}.\
        #             habitat{}.\You have submitted the form successfully! <h1>'.format(chp, od, gil, pop, hab)

    return redirect('/predict.html')
@app.route('/result')
def result():
    cur = mysql.connection.cursor()
    cur.execute("SELECT cap-shape,odor,gill-size,population,habitat FROM mushroom WHERE id=(SELECT MAX(id) FROM mushroom);")
    #to_predict_list = cur.fetchall()

    results = cur.fetchall()

    return '<h1>chp {}. od{}. gil{}. pop {}. hab{}. </h1>'.format(results[0]['cap-shape'],results[0]['odor'],results[0]['gil-size'], results[0]['population'],results[0]['habitat'])
    pred = model.predict(results)
    print(pred)
    if 1 in pred:
        output = 'Poisonous'
    if 0 in pred:
        output = 'Edible'

     #return render_template('/predict.html', prediction='This mushroom is Edible!!.'.format(chp,od,gil,pop,hab))
    return render_template("results.html", prediction="Your MUSHROOM is : {} !!! . . .".format(output))

if __name__=="__main__":
         app.run(debug=True, port=5000)